/**
 * ═══════════════════════════════════════════════════════
 *  ErgoNOM v2.0 — Google Apps Script API
 *  NOM-036-STPS-2018
 * ═══════════════════════════════════════════════════════
 *
 *  INSTRUCCIONES DE INSTALACIÓN:
 *  1. Abre tu Google Sheet
 *  2. Extensiones → Apps Script
 *  3. Pega TODO este código (reemplaza el contenido existente)
 *  4. Guarda (Ctrl+S)
 *  5. Implementar → Nueva implementación
 *     - Tipo: Aplicación web
 *     - Ejecutar como: Yo
 *     - Quién puede acceder: Cualquier usuario
 *  6. Autoriza los permisos
 *  7. Copia la URL de implementación → pégala en ErgoNOM
 * ═══════════════════════════════════════════════════════
 */

// ── Nombre de la hoja donde se guardan los datos ──
const SHEET_NAME = 'Evaluaciones';

// ── Columnas de la hoja (orden exacto) ──
const COLUMNS = [
  'Folio',
  'Fecha',
  'Hora',
  'Empresa',
  'Área',
  'Puesto',
  'Método',
  'Puntuación',
  'Nivel de Riesgo',
  'Riesgo',
  'Ángulo Cuello (°)',
  'Ángulo Tronco (°)',
  'Ángulo Hombro Izq (°)',
  'Ángulo Codo Izq (°)',
  'Ángulo Cadera Izq (°)',
  'Ángulo Rodilla Izq (°)',
  'Observaciones',
  'Timestamp',
];

// ══════════════════════════════════════════════════════
//  ENTRY POINT — maneja GET y POST
// ══════════════════════════════════════════════════════

function doGet(e) {
  const action = e.parameter.action || 'read';

  if (action === 'read') {
    return jsonResponse(readEvaluations());
  }

  if (action === 'stats') {
    return jsonResponse(getStats());
  }

  return jsonResponse({ error: 'Acción no reconocida', actions: ['read', 'stats'] });
}

function doPost(e) {
  try {
    const body = JSON.parse(e.postData.contents);
    const action = body.action || 'save';

    if (action === 'save') {
      return jsonResponse(saveEvaluation(body.data));
    }

    if (action === 'delete') {
      return jsonResponse(deleteEvaluation(body.folio));
    }

    if (action === 'saveBatch') {
      return jsonResponse(saveBatch(body.data));
    }

    return jsonResponse({ error: 'Acción no reconocida' });

  } catch (err) {
    return jsonResponse({ error: err.message });
  }
}

// ══════════════════════════════════════════════════════
//  FUNCIONES PRINCIPALES
// ══════════════════════════════════════════════════════

/**
 * Guarda una evaluación en la hoja
 */
function saveEvaluation(data) {
  const sheet = getOrCreateSheet();
  const now   = new Date();

  const row = [
    data.folio       || 'ERG-' + Date.now().toString().slice(-6),
    data.date        || now.toLocaleDateString('es-MX'),
    now.toLocaleTimeString('es-MX'),
    data.empresa     || '—',
    data.area        || '—',
    data.puesto      || '—',
    data.method      || '—',
    data.score       || '—',
    getRiskLabel(data.risk),
    data.risk        || '—',
    data.angles?.neck           || '—',
    data.angles?.trunk          || '—',
    data.angles?.['shoulder_l'] || '—',
    data.angles?.['elbow_l']    || '—',
    data.angles?.['hip_l']      || '—',
    data.angles?.['knee_l']     || '—',
    data.observaciones || '',
    now.toISOString(),
  ];

  sheet.appendRow(row);
  formatLastRow(sheet);

  return {
    success: true,
    folio: row[0],
    message: `Evaluación ${row[0]} guardada correctamente`,
  };
}

/**
 * Guarda múltiples evaluaciones de una vez (sincronización inicial)
 */
function saveBatch(dataArray) {
  if (!Array.isArray(dataArray)) return { error: 'Se esperaba un array' };

  const sheet = getOrCreateSheet();
  const now   = new Date();
  let count   = 0;

  dataArray.forEach(data => {
    const row = [
      data.folio       || 'ERG-' + Date.now().toString().slice(-6),
      data.date        || now.toLocaleDateString('es-MX'),
      now.toLocaleTimeString('es-MX'),
      data.empresa     || '—',
      data.area        || '—',
      data.puesto      || '—',
      data.method      || '—',
      data.score       || '—',
      getRiskLabel(data.risk),
      data.risk        || '—',
      data.angles?.neck           || '—',
      data.angles?.trunk          || '—',
      data.angles?.['shoulder_l'] || '—',
      data.angles?.['elbow_l']    || '—',
      data.angles?.['hip_l']      || '—',
      data.angles?.['knee_l']     || '—',
      data.observaciones || '',
      now.toISOString(),
    ];
    sheet.appendRow(row);
    count++;
  });

  applyFullFormatting(sheet);
  return { success: true, saved: count };
}

/**
 * Lee todas las evaluaciones y las retorna como JSON
 */
function readEvaluations() {
  const sheet = getOrCreateSheet();
  const data  = sheet.getDataRange().getValues();

  if (data.length <= 1) return { evaluations: [], total: 0 };

  const headers = data[0];
  const rows    = data.slice(1).map(row => {
    const obj = {};
    headers.forEach((h, i) => { obj[h] = row[i]; });
    return obj;
  });

  return { evaluations: rows.reverse(), total: rows.length };
}

/**
 * Elimina una fila por folio
 */
function deleteEvaluation(folio) {
  const sheet = getOrCreateSheet();
  const data  = sheet.getDataRange().getValues();

  for (let i = data.length - 1; i >= 1; i--) {
    if (String(data[i][0]) === String(folio)) {
      sheet.deleteRow(i + 1);
      return { success: true, deleted: folio };
    }
  }
  return { success: false, message: 'Folio no encontrado' };
}

/**
 * Estadísticas generales
 */
function getStats() {
  const sheet = getOrCreateSheet();
  const data  = sheet.getDataRange().getValues();
  if (data.length <= 1) return { total: 0, byRisk: {}, byMethod: {} };

  const rows = data.slice(1);
  const byRisk   = { low: 0, med: 0, high: 0 };
  const byMethod = {};

  rows.forEach(row => {
    const risk   = row[9];  // columna Riesgo
    const method = row[6];  // columna Método
    if (byRisk[risk] !== undefined) byRisk[risk]++;
    byMethod[method] = (byMethod[method] || 0) + 1;
  });

  return { total: rows.length, byRisk, byMethod };
}

// ══════════════════════════════════════════════════════
//  HELPERS DE HOJA
// ══════════════════════════════════════════════════════

function getOrCreateSheet() {
  const ss    = SpreadsheetApp.getActiveSpreadsheet();
  let sheet   = ss.getSheetByName(SHEET_NAME);

  if (!sheet) {
    sheet = ss.insertSheet(SHEET_NAME);
    setupHeaders(sheet);
  } else if (sheet.getLastRow() === 0) {
    setupHeaders(sheet);
  }

  return sheet;
}

function setupHeaders(sheet) {
  sheet.appendRow(COLUMNS);

  // Formato del encabezado
  const headerRange = sheet.getRange(1, 1, 1, COLUMNS.length);
  headerRange.setBackground('#0d1117');
  headerRange.setFontColor('#00d4aa');
  headerRange.setFontWeight('bold');
  headerRange.setFontSize(10);

  // Ancho de columnas
  sheet.setColumnWidth(1, 100);  // Folio
  sheet.setColumnWidth(2, 100);  // Fecha
  sheet.setColumnWidth(3, 80);   // Hora
  sheet.setColumnWidth(4, 140);  // Empresa
  sheet.setColumnWidth(5, 120);  // Área
  sheet.setColumnWidth(6, 140);  // Puesto
  sheet.setColumnWidth(7, 80);   // Método
  sheet.setColumnWidth(8, 100);  // Puntuación
  sheet.setColumnWidth(9, 130);  // Nivel
  sheet.setColumnWidth(10, 80);  // Riesgo
  for (let i = 11; i <= 16; i++) sheet.setColumnWidth(i, 90);
  sheet.setColumnWidth(17, 200); // Observaciones
  sheet.setColumnWidth(18, 150); // Timestamp

  // Fila fija
  sheet.setFrozenRows(1);
}

function formatLastRow(sheet) {
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return;

  const range = sheet.getRange(lastRow, 1, 1, COLUMNS.length);
  const risk  = sheet.getRange(lastRow, 10).getValue();

  // Color de fondo según riesgo
  const colors = { low: '#f0fff4', med: '#fffbeb', high: '#fff1f0' };
  range.setBackground(colors[risk] || '#ffffff');

  // Borde inferior
  range.setBorder(false, false, true, false, false, false, '#e2e8f0', SpreadsheetApp.BorderStyle.SOLID);
}

function applyFullFormatting(sheet) {
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return;
  for (let i = 2; i <= lastRow; i++) {
    const risk  = sheet.getRange(i, 10).getValue();
    const range = sheet.getRange(i, 1, 1, COLUMNS.length);
    const colors = { low: '#f0fff4', med: '#fffbeb', high: '#fff1f0' };
    range.setBackground(colors[risk] || '#ffffff');
  }
}

function getRiskLabel(risk) {
  return { low: 'BAJO', med: 'MODERADO', high: 'ALTO' }[risk] || '—';
}

/**
 * Respuesta JSON con headers CORS para GitHub Pages
 */
function jsonResponse(data) {
  return ContentService
    .createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}
