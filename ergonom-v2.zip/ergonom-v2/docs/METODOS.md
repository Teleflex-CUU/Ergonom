# Métodos ergonómicos — Referencia rápida

Resumen de los métodos implementados en ErgoNOM y su aplicación según la NOM-036-STPS-2018.

---

## REBA — Rapid Entire Body Assessment

**Autor:** Hignett & McAtamney (2000)  
**Aplicación:** Evaluación del riesgo de trastornos musculoesqueléticos en tareas que involucran el cuerpo completo.

### Cuándo usarlo
- Trabajo de pie con postura variable
- Tareas con carga o esfuerzo físico
- Sectores: manufactura, salud, construcción, almacén

### Segmentos evaluados
Grupo A: Tronco, cuello, piernas  
Grupo B: Brazo superior, antebrazo, muñeca

### Puntuación e interpretación

| Puntuación | Nivel de riesgo | Acción |
|-----------|----------------|--------|
| 1 | Negligible | Sin acción necesaria |
| 2–3 | Bajo | Puede necesitar cambios |
| 4–7 | Medio | Investigar y cambiar pronto |
| 8–10 | Alto | Cambio a corto plazo |
| 11–15 | Muy alto | Cambio inmediato |

---

## RULA — Rapid Upper Limb Assessment

**Autor:** McAtamney & Corlett (1993)  
**Aplicación:** Evaluación de carga musculoesquelética en miembros superiores.

### Cuándo usarlo
- Trabajo de oficina / pantallas
- Ensamble fino o de precisión
- Trabajo sedentario con uso intensivo de brazos

### Puntuación

| Puntuación | Acción |
|-----------|--------|
| 1–2 | Sin cambios |
| 3–4 | Cambios en el futuro próximo |
| 5–6 | Investigar y cambiar pronto |
| 7 | Cambio inmediato |

---

## NIOSH — Ecuación Revisada de NIOSH (1994)

**Aplicación:** Evaluación de levantamiento manual de cargas.

### Variables requeridas
- **H** — Distancia horizontal manos–tobillo (cm)
- **V** — Altura vertical de manos al inicio (cm)
- **D** — Distancia vertical del recorrido (cm)
- **A** — Ángulo de asimetría (grados)
- **F** — Frecuencia de levantamientos/minuto
- **C** — Tipo de agarre (bueno / regular / pobre)

### Indicadores de resultado

| IL (Índice de Levantamiento) | Interpretación |
|-----------------------------|----------------|
| ≤ 1.0 | Tarea segura |
| 1.0 – 2.0 | Incrementar control |
| > 2.0 | Rediseño urgente |

---

## OCRA — Occupational Repetitive Actions

**Autor:** Occhipinti (1998) / ISO 11228-3  
**Aplicación:** Trabajo repetitivo de miembros superiores por ciclos.

### Índice OCRA

| Índice | Clasificación |
|--------|---------------|
| ≤ 7.5 | Aceptable |
| 7.6 – 11 | Zona roja muy leve |
| 11.1 – 22.5 | Riesgo medio |
| > 22.5 | Riesgo alto |

---

## OWAS — Ovako Working Posture Analysis System

**Autor:** Karhu et al. (1977)  
**Aplicación:** Clasificación sistemática de posturas globales.

### Categorías de acción

| Categoría | Significado |
|-----------|------------|
| 1 | No requiere acción |
| 2 | Acción en el futuro |
| 3 | Acción a corto plazo |
| 4 | Acción inmediata |

---

## JSI — Job Strain Index

**Autor:** Moore & Garg (1995)  
**Aplicación:** Riesgo de TME en mano, muñeca y antebrazo distal.

### Multiplicadores (6 factores)
1. Intensidad del esfuerzo (IE)
2. Duración del esfuerzo por ciclo (DE)
3. Esfuerzos por minuto (EM)
4. Postura de la muñeca (PW)
5. Velocidad del trabajo (SW)
6. Duración de la tarea por día (DD)

### Interpretación

| JSI | Clasificación |
|-----|---------------|
| ≤ 3 | Seguro |
| 3 – 5 | No determinado |
| > 5 | Peligroso |

---

## Selección del método según NOM-036-STPS-2018

```
¿Hay manejo manual de cargas?
  └─ SÍ → NIOSH (obligatorio)
  └─ NO ↓

¿Predominan extremidades superiores?
  ├─ Trabajo de precisión/oficina → RULA
  ├─ Alta repetitividad → OCRA / JSI
  └─ Cuerpo completo → REBA / OWAS
```
