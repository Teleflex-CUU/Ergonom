# Guía de integración: MediaPipe Pose

Esta guía explica cómo reemplazar el simulador de pose (`poseSimulator.js`) por
detección de pose **real** usando [MediaPipe Pose](https://developers.google.com/mediapipe/solutions/vision/pose_landmarker)
directamente en el navegador, sin servidor.

---

## 1. Instalar / cargar MediaPipe

### Opción A — CDN (más rápida)
```html
<!-- En index.html, antes de cerrar </body> -->
<script src="https://cdn.jsdelivr.net/npm/@mediapipe/pose/pose.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@mediapipe/camera_utils/camera_utils.js"></script>
```

### Opción B — npm
```bash
npm install @mediapipe/pose @mediapipe/camera_utils
```

---

## 2. Inicializar el detector de pose

```javascript
// En VideoAnalyzer.js, dentro de loadFile()
import { Pose } from '@mediapipe/pose';

const pose = new Pose({
  locateFile: (file) =>
    `https://cdn.jsdelivr.net/npm/@mediapipe/pose/${file}`,
});

pose.setOptions({
  modelComplexity: 1,       // 0=lite, 1=full, 2=heavy
  smoothLandmarks: true,
  enableSegmentation: false,
  minDetectionConfidence: 0.5,
  minTrackingConfidence: 0.5,
});

pose.onResults((results) => {
  if (!results.poseLandmarks) return;
  const landmarks = results.poseLandmarks; // Array de 33 puntos
  onPoseFrame(landmarks);
});
```

---

## 3. Mapeo de landmarks MediaPipe → joints ErgoNOM

MediaPipe retorna 33 landmarks. Este es el mapeo recomendado:

| ErgoNOM joint | MediaPipe índice | Nombre MediaPipe        |
|---------------|-----------------|-------------------------|
| `nariz`       | 0               | NOSE                    |
| `ojo_i`       | 2               | LEFT_EYE                |
| `ojo_d`       | 5               | RIGHT_EYE               |
| `hombro_i`    | 11              | LEFT_SHOULDER           |
| `hombro_d`    | 12              | RIGHT_SHOULDER          |
| `codo_i`      | 13              | LEFT_ELBOW              |
| `codo_d`      | 14              | RIGHT_ELBOW             |
| `muñeca_i`    | 15              | LEFT_WRIST              |
| `muñeca_d`    | 16              | RIGHT_WRIST             |
| `cadera_i`    | 23              | LEFT_HIP                |
| `cadera_d`    | 24              | RIGHT_HIP               |
| `rodilla_i`   | 25              | LEFT_KNEE               |
| `rodilla_d`   | 26              | RIGHT_KNEE              |
| `tobillo_i`   | 27              | LEFT_ANKLE              |
| `tobillo_d`   | 28              | RIGHT_ANKLE             |

```javascript
// Función de conversión
function landmarksToJoints(landmarks, canvasW, canvasH) {
  const idx = {
    nariz: 0, ojo_i: 2, ojo_d: 5,
    hombro_i: 11, hombro_d: 12,
    codo_i: 13, codo_d: 14,
    muñeca_i: 15, muñeca_d: 16,
    cadera_i: 23, cadera_d: 24,
    rodilla_i: 25, rodilla_d: 26,
    tobillo_i: 27, tobillo_d: 28,
  };

  const joints = {};
  for (const [name, i] of Object.entries(idx)) {
    const lm = landmarks[i];
    if (lm && lm.visibility > 0.5) {
      joints[name] = [lm.x * canvasW, lm.y * canvasH];
    }
  }
  return joints;
}
```

---

## 4. Calcular ángulos reales para REBA / RULA

```javascript
/**
 * Calcula el ángulo en grados entre tres puntos (A→B→C).
 * B es el vértice (articulación).
 */
function angleBetween(A, B, C) {
  const vBA = [A[0] - B[0], A[1] - B[1]];
  const vBC = [C[0] - B[0], C[1] - B[1]];

  const dot     = vBA[0]*vBC[0] + vBA[1]*vBC[1];
  const magBA   = Math.hypot(...vBA);
  const magBC   = Math.hypot(...vBC);
  const cosAngle = dot / (magBA * magBC);

  return Math.round(Math.acos(Math.min(1, Math.max(-1, cosAngle))) * (180 / Math.PI));
}

// Ejemplo: ángulo de codo izquierdo
function onPoseFrame(landmarks) {
  const joints = landmarksToJoints(landmarks, canvas.width, canvas.height);

  const elbowAngle = angleBetween(
    joints.hombro_i,
    joints.codo_i,
    joints.muñeca_i,
  );

  const neckAngle  = angleBetween(
    joints.hombro_i,  // aproximación de hombro como referencia
    joints.nariz,
    [joints.nariz[0], joints.nariz[1] + 50], // vertical
  );

  // Pasar a riskScorer
  const rebaResult = calculateREBA({
    neckAngle,
    upperArmAngle: 180 - elbowAngle,
    // ... resto de ángulos
  });

  // Renderizar con los joints reales
  renderSkeleton(ctx, 0, joints);
}
```

---

## 5. Procesar video frame a frame

```javascript
// Enviar cada frame al detector de pose
async function processVideoFrames(videoEl, pose) {
  const sendFrame = async () => {
    if (videoEl.paused || videoEl.ended) return;
    await pose.send({ image: videoEl });
    requestAnimationFrame(sendFrame);
  };

  videoEl.addEventListener('play', sendFrame);
}
```

---

## Resultado esperado

Con esta integración obtendrás:
- Puntos de esqueleto detectados en tiempo real sobre el video
- Ángulos articulares calculados automáticamente
- Puntuación REBA / RULA actualizada frame a frame
- Distribución de riesgo acumulada durante toda la tarea

---

## Recursos

- [MediaPipe Pose — Documentación](https://developers.google.com/mediapipe/solutions/vision/pose_landmarker)
- [MoveNet (TensorFlow.js)](https://www.tensorflow.org/hub/tutorials/movenet) — alternativa más rápida
- [OpenPose](https://github.com/CMU-Perceptual-Computing-Lab/openpose) — para procesamiento en servidor
