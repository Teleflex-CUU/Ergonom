# 🦴 ErgoNOM v2.0 — Análisis Ergonómico NOM-036-STPS-2018

![Version](https://img.shields.io/badge/versión-2.0.0-brightgreen)
![NOM](https://img.shields.io/badge/NOM--036--STPS-2018-blue)
![MediaPipe](https://img.shields.io/badge/MediaPipe_Pose-integrado-purple)
![License](https://img.shields.io/badge/licencia-MIT-orange)
![Sin dependencias npm](https://img.shields.io/badge/deps-0_npm-lightgrey)

Plataforma web completa de análisis ergonómico ocupacional basada en la **NOM-036-STPS-2018** de México.
Incluye detección real de esqueleto con **MediaPipe Pose**, calculadoras para **8 métodos ergonómicos**,
exportación PDF y dashboard histórico. Todo en un solo archivo HTML sin servidor.

---

## ✨ Nuevas características v2.0

| Módulo | Descripción |
|--------|-------------|
| 🧠 **IA + Claude** | Análisis de actividad → recomendación automática de método |
| 🎬 **MediaPipe Pose** | Detección real de esqueleto en video + vectores de riesgo |
| 📐 **8 Calculadoras** | REBA · RULA · NIOSH · OCRA · OWAS · JSI · RSI · OSHA |
| 📊 **Dashboard** | Historial con gráficas Chart.js + estadísticas por nivel de riesgo |
| 📋 **Reporte NOM-036** | PDF exportable con jsPDF + cumplimiento por artículo |
| 📚 **Documentación** | Referencia técnica interactiva de todos los modelos |
| 💾 **Persistencia** | localStorage — historial entre sesiones |

---

## 🚀 Inicio rápido

```bash
git clone https://github.com/tu-usuario/ergonom-036.git
cd ergonom-036
open index.html   # o python3 -m http.server 8080
```

No requiere npm, no requiere servidor, no requiere build step.

---

## 🔬 Métodos implementados

### 1. REBA — Rapid Entire Body Assessment
- Evalúa cuerpo completo con tablas A, B y C completas
- Modificadores: carga, agarre, actividad muscular
- Puntuación 1-15 con 5 niveles de riesgo
- **Integrado con MediaPipe**: ángulos reales → puntuación automática

### 2. RULA — Rapid Upper Limb Assessment
- Grupos A (MMSS) y B (cuello/tronco/piernas)
- Modificadores de fuerza y uso muscular
- Puntuación 1-7

### 3. NIOSH — Ecuación Revisada 1994
- 6 multiplicadores: HM, VM, DM, AM, FM, CM
- Cálculo de LPR e Índice de Levantamiento
- Tabla FM completa por frecuencia y duración

### 4. OCRA — Occupational Repetitive Actions
- Índice OCRA con ATA observadas vs. referencia
- Factores: frecuencia, fuerza, postura, adicionales, recuperación
- Referenciado en ISO 11228-3

### 5. OWAS — Ovako Working Posture Analysis
- Código postural 4 dígitos (espalda-brazos-piernas-carga)
- Tabla de categorías 1-4 completa
- Ideal para muestreo de trabajo

### 6. JSI — Job Strain Index
- 6 multiplicadores para mano/muñeca/antebrazo distal
- Umbrales: <3 seguro, 3-5 incierto, >5 peligroso

### 7. RSI — Revised Strain Index
- Versión revisada Moore et al. 2011
- Incorpora % tiempo con muñeca desviada
- Mayor precisión para TME de mano

### 8. Check-List OSHA / NOM-036
- 17 ítems ponderados por segmento y factor de riesgo
- Categorías: cuello, hombros, espalda, muñeca, fuerza, repetitividad, ambiente
- Puntuación porcentual para priorización

---

## 🎬 Integración MediaPipe Pose

La app integra **MediaPipe Pose** directamente desde CDN. Cuando detecta pose real:

- Dibuja 33 keypoints sobre el video en tiempo real
- Colorea cada joint y conexión según nivel de riesgo (🟢🟡🔴)
- Muestra el ángulo en grados junto a articulaciones clave
- Alimenta automáticamente la calculadora REBA con los ángulos reales
- Actualiza el panel de segmentos corporales frame a frame

```
Carga el video → MediaPipe detecta pose → Ángulos calculados → 
REBA score automático → Distribución de riesgo actualizada
```

Si MediaPipe no está disponible (sin conexión), se activa una **simulación de pose** para demostración.

---

## 📂 Estructura del proyecto

```
ergonom-036/
├── index.html          ← App completa (2,958 líneas, standalone)
├── README.md
├── LICENSE
├── .gitignore
└── docs/
    ├── METODOS.md                   ← Referencia técnica de los 8 métodos
    ├── INTEGRACION-MEDIAPIPE.md     ← Guía de integración pose real
    └── NOM-036-RESUMEN.md           ← Resumen de artículos relevantes
```

---

## 🗺️ Roadmap v3.0

- [ ] Análisis de múltiples trabajadores en el mismo video
- [ ] Exportación de video con overlay de vectores grabado
- [ ] SNOOK Tables para empuje/jale
- [ ] Liberty Mutual Tables
- [ ] Modo PWA (offline)
- [ ] Sincronización Firebase para equipos
- [ ] Integración con IMSS / STPS reporting

---

## 📋 Artículos NOM-036-STPS-2018 cubiertos

| Artículo | Tema | Módulo |
|----------|------|--------|
| Art. 8 | Identificación de factores de riesgo | Describir + IA |
| Art. 9 | Evaluación cuantitativa | Calculadoras + Video |
| Art. 14 | Medidas de prevención | Reporte |
| Art. 16 | Rotación y recuperación | Plan de acción |
| Art. 20 | Registros documentales | Dashboard + PDF |

---

## 📄 Licencia

MIT © 2025 — ErgoNOM

> Herramienta de apoyo profesional. No reemplaza la evaluación de un especialista certificado en ergonomía.
